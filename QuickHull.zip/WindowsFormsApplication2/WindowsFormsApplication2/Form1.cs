﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        HashSet<KeyValuePair<int, int>> hull;
        List<KeyValuePair<int, int>> points;
        Graphics graph;
        bool fin;

        public Form1()
        {
            InitializeComponent();
            hull = new HashSet<KeyValuePair<int, int>>();
            points = new List<KeyValuePair<int, int>>();
            graph = CreateGraphics();
            fin = false;
        }
    

        // Returns the side of point p with respect to line 
        // joining points p1 and p2. 
        int findSide(KeyValuePair<int, int> p1, KeyValuePair<int, int> p2, KeyValuePair<int, int> p)
        {
            int val = (p.Value - p1.Value) * (p2.Key - p1.Key) -
                (p2.Value - p1.Value) * (p.Key - p1.Key);

            if (val > 0)
                return 1;
            if (val < 0)
                return -1;
            return 0;
        }

        // Returns the square of distance between 
        // p1 and p2. 
        int dist(KeyValuePair<int, int> p, KeyValuePair<int, int> q)
        {
            return (p.Value - q.Value) * (p.Value - q.Value) +
                (p.Key - q.Key) * (p.Key - q.Key);
        }

        // returns a value proportional to the distance 
        // between the point p and the line joining the 
        // points p1 and p2 
        int lineDist(KeyValuePair<int, int> p1, KeyValuePair<int, int> p2, KeyValuePair<int, int> p)
        {
            return Math.Abs((p.Value - p1.Value) * (p2.Key - p1.Key) -
                (p2.Value - p1.Value) * (p.Key - p1.Key));
        }

        // End points of line L are p1 and p2.  side can have value 
        // 1 or -1 specifying each of the parts made by the line L 
        void quickHull(List<KeyValuePair<int, int>> a, int n, KeyValuePair<int, int> p1, KeyValuePair<int, int> p2, int side)
        {
            int ind = -1;
            int max_dist = 0;

            // finding the point with maximum distance 
            // from L and also on the specified side of L. 
            for (int i = 0; i < n; i++)
            {
                int temp = lineDist(p1, p2, a[i]);
                if (findSide(p1, p2, a[i]) == side && temp > max_dist)
                {
                    ind = i;
                    max_dist = temp;
                }
            }

            // If no point is found, add the end points 
            // of L to the convex hull. 
            if (ind == -1)
            {
                hull.Add(p1);
                hull.Add(p2);
                return;
            }

            // Recur for the two parts divided by a[ind] 
            quickHull(a, n, a[ind], p1, -findSide(a[ind], p1, p2));
            quickHull(a, n, a[ind], p2, -findSide(a[ind], p2, p1));
        }

        void printHull(List<KeyValuePair<int, int>> a, int n)
        {
            // a[i].second -> y-coordinate of the ith point 
            if (n < 3)
            {
                //cout << "Convex hull not possible\n";
                return;
            }

            // Finding the point with minimum and 
            // maximum x-coordinate 
            int min_x = 0, max_x = 0;
            for (int i = 1; i < n; i++)
            {
                if (a[i].Key < a[min_x].Key)
                    min_x = i;
                if (a[i].Key > a[max_x].Key)
                    max_x = i;
            }

            // Recursively find convex hull points on 
            // one side of line joining a[min_x] and 
            // a[max_x] 
            quickHull(a, n, a[min_x], a[max_x], 1);

            // Recursively find convex hull points on 
            // other side of line joining a[min_x] and 
            // a[max_x] 
            quickHull(a, n, a[min_x], a[max_x], -1);

            //cout << "The points in Convex Hull are:\n";
           /* while (hull.Count > 0)
            {
               // cout << "(" << (*hull.begin()).first << ", "
               //     << (*hull.begin()).second << ") ";
                hull.Remove(hull.First());
            }*/
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            KeyValuePair<int, int> p = new KeyValuePair<int, int>(e.X, e.Y);
            points.Add(p);
            if (!fin)
                this.Refresh();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            foreach (KeyValuePair<int, int> tp in points)
            {
                e.Graphics.FillEllipse(Brushes.Red, new Rectangle(new Point(tp.Key, tp.Value), new Size(3, 3)));
            }
        }

        class PointAngleComparer : Comparer<KeyValuePair<double, Point>>
        {
            public override int Compare(KeyValuePair<double, Point> p1, KeyValuePair<double, Point> p2)
            {
                if (p1.Key < p2.Key)
                    return 1;
                else if (p2.Key < p1.Key)
                    return -1;
                else
                    return 0;
            }
        }

        private void SortPointsByAngle(List<Point> res)
        {
            Point centroid = new Point();
            int sum_x = 0;
            int sum_y = 0;
            foreach (Point p in res)
            {
                sum_x += p.X;
                sum_y += p.Y;
            }
            centroid.X = sum_x / res.Count;
            centroid.Y = sum_y / res.Count;

            List<KeyValuePair<double, Point>> l = new List<KeyValuePair<double, Point>>();
            foreach (Point p in res)
            {
                double angle = Math.Atan2(p.Y - centroid.Y, p.X - centroid.X);
                l.Add(new KeyValuePair<double, Point>(angle, p));
            }
            l.Sort(new PointAngleComparer());

            res.Clear();

            foreach (KeyValuePair<double, Point> x in l)
            {
                res.Add(x.Value);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "Готово")
            {
                fin = true;
                printHull(points, points.Count);
                List<Point> res = new List<Point>();
                foreach (KeyValuePair<int, int> p in hull)
                {
                    res.Add(new Point(p.Key, p.Value));
                }
                SortPointsByAngle(res);
                graph.DrawPolygon(Pens.Blue, res.ToArray());
                button1.Text = "Очистить";
            }
            else
            {
                graph.Clear(Form1.DefaultBackColor);
                points.Clear();
                fin = false;
                button1.Text = "Готово";
            }
        }

        
    }
}
